<?php



function load_theme_styles()
{
	// Ladda stilmallen för temat (style.css)

	// Dynamiskt versionsnummer baserat på filens ändringstid för att undvika cachingproblem
	$style_version = filemtime(get_template_directory() . '/style.css');

	// Köa stilmallen
	wp_enqueue_style(
		'testtema-style', // Unikt ID (handle) för stilmallen
		get_template_directory_uri() . '/style.css', // URL till stilmallen
		array(), // Beroenden, om en css fil behöver laddas in före denna ex. (lämna tom om det inte finns några)
		$style_version, // Dynamiskt versionsnummer nu baserat på filändringstid (Vilket är bra under utveckling så man slipper cachingproblem)
		'all' // Mediatyp (all = för alla medier, som skärmar och skrivare)
	);
}

// Anropa funktionen när WordPress laddar stilmallar
add_action('wp_enqueue_scripts', 'load_theme_styles');
